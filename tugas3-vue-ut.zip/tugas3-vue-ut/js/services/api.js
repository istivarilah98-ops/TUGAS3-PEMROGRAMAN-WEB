// Mengambil data awal dari file JSON.
window.dataService = {
    ambilData: function () {
        return fetch('./data/dataBahanAjar.json')
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('File dataBahanAjar.json tidak ditemukan.');
                }
                return response.json();
            })
            .then(function (data) {
                // Data tracking dari JSON berbentuk array berisi object dengan nomor DO sebagai key.
                var daftarTracking = [];
                data.tracking.forEach(function (item) {
                    Object.keys(item).forEach(function (nomorDo) {
                        var detail = item[nomorDo];
                        var sudahAda = daftarTracking.some(function (doItem) {
                            return doItem.nomorDo === nomorDo;
                        });

                        if (!sudahAda) {
                            daftarTracking.push({
                                nomorDo: nomorDo,
                                nim: detail.nim,
                                nama: detail.nama,
                                status: detail.status,
                                ekspedisi: detail.ekspedisi,
                                tanggalKirim: detail.tanggalKirim,
                                paket: detail.paket,
                                total: detail.total,
                                perjalanan: detail.perjalanan || []
                            });
                        }
                    });
                });

                data.tracking = daftarTracking;
                return data;
            });
    }
};
