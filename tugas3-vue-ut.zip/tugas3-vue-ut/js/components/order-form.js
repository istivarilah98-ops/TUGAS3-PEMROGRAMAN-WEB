
// Komponen formulir Delivery Order baru.
window.orderFormReady = fetch('./templates/order-form.html')
    .then(function (response) {
        if (!response.ok) {
            throw new Error('Template order-form.html gagal dimuat.');
        }
        return response.text();
    })
    .then(function (templateHtml) {
        Vue.component('order-form', {
            template: templateHtml,
            props: ['paketList', 'pengirimanList', 'nomorDo'],

            data: function () {
                return {
                    formOrder: {
                        nim: '',
                        nama: '',
                        ekspedisi: '',
                        paket: '',
                        tanggalKirim: new Date().toISOString().slice(0, 10)
                    }
                };
            },

            computed: {
                paketDipilih: function () {
                    return this.paketList.find(function (paket) {
                        return paket.kode === this.formOrder.paket;
                    }, this) || null;
                }
            },

            methods: {
                formatRupiah: function (angka) {
                    return 'Rp ' + Number(angka).toLocaleString('id-ID');
                },

                simpanOrder: function () {
                    if (
                        !this.formOrder.nim.trim() ||
                        !this.formOrder.nama.trim() ||
                        !this.formOrder.ekspedisi ||
                        !this.paketDipilih ||
                        !this.formOrder.tanggalKirim
                    ) {
                        this.$root.$refs.appModal.tampilkan(
                            'Mohon lengkapi data Delivery Order.'
                        );
                        return;
                    }

                    this.$emit('simpan-do', {
                        nomorDo: this.nomorDo,
                        nim: this.formOrder.nim.trim(),
                        nama: this.formOrder.nama.trim(),
                        ekspedisi: this.formOrder.ekspedisi,
                        tanggalKirim: this.formOrder.tanggalKirim,
                        paket: this.paketDipilih.kode,
                        total: this.paketDipilih.harga,
                        status: 'Dalam Perjalanan',
                        perjalanan: [{
                            waktu: new Date().toLocaleString('id-ID'),
                            keterangan: 'Delivery Order dibuat'
                        }]
                    });

                    this.formOrder = {
                        nim: '',
                        nama: '',
                        ekspedisi: '',
                        paket: '',
                        tanggalKirim: new Date().toISOString().slice(0, 10)
                    };
                }
            }
        });
    });
