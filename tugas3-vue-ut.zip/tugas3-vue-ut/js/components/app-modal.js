// Komponen modal sederhana untuk konfirmasi.
window.appModalReady = fetch('./templates/app-modal.html')
    .then(function (response) {
        if (!response.ok) {
            throw new Error('Template app-modal.html gagal dimuat.');
        }
        return response.text();
    })
    .then(function (templateHtml) {
        Vue.component('app-modal', {
            template: templateHtml,
            data: function () {
                return {
                    terbuka: false,
                    pesan: ''
                };
            },
            methods: {
                tampilkan: function (pesan) {
                    this.pesan = pesan;
                    this.terbuka = true;
                },
                tutup: function () {
                    this.terbuka = false;
                }
            }
        });
    });
