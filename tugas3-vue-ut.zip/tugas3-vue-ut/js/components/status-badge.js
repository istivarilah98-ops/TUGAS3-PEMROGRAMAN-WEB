// Komponen untuk menampilkan status stok.
window.statusBadgeReady = fetch('./templates/status-badge.html')
    .then(function (response) {
        if (!response.ok) {
            throw new Error('Template status-badge.html gagal dimuat.');
        }
        return response.text();
    })
    .then(function (templateHtml) {
        Vue.component('status-badge', {
            template: templateHtml,
            props: ['item'],
            computed: {
                statusStok: function () {
                    if (this.item.qty === 0) {
                        return { teks: 'Kosong', simbol: '❌' };
                    }
                    if (this.item.qty < this.item.safety) {
                        return { teks: 'Menipis', simbol: '⚠️' };
                    }
                    return { teks: 'Aman', simbol: '✅' };
                }
            }
        });
    });
