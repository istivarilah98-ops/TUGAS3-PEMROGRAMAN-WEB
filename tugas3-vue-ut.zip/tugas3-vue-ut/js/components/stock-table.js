window.stockTableReady = fetch('./templates/stock-table.html')
    .then(function (response) {
        if (!response.ok) {
            throw new Error('Template stock-table.html gagal dimuat.');
        }
        return response.text();
    })
    .then(function (templateHtml) {
        Vue.component('ba-stock-table', {
            template: templateHtml,

            props: ['items', 'upbjjList', 'kategoriList'],

            data: function () {
                return {
                    kataKunci: '',
                    filterUpbjj: '',
                    filterKategori: '',
                    filterStok: 'semua',
                    urutkan: 'judul',

                    sedangEdit: false,
                    formTampil: false,

                    modalHapusTampil: false,
                    modalPesanTampil: false,
                    kodeHapus: '',
                    pesanModal: '',

                    formStok: {
                        kode: '',
                        judul: '',
                        kategori: '',
                        upbjj: '',
                        lokasiRak: '',
                        harga: 0,
                        qty: 0,
                        safety: 0,
                        catatanHTML: ''
                    }
                };
            },

            computed: {
                pilihanKategori: function () {
                    if (!this.filterUpbjj) {
                        return this.kategoriList;
                    }

                    return this.items.filter(function (item) {
                        return item.upbjj === this.filterUpbjj;
                    }, this).map(function (item) {
                        return item.kategori;
                    }).filter(function (kategori, index, daftar) {
                        return daftar.indexOf(kategori) === index;
                    });
                },

                daftarStok: function () {
                    var hasil = this.items.filter(function (item) {
                        var cocokKata =
                            item.kode.toLowerCase().includes(this.kataKunci.toLowerCase()) ||
                            item.judul.toLowerCase().includes(this.kataKunci.toLowerCase());

                        var cocokUpbjj =
                            !this.filterUpbjj || item.upbjj === this.filterUpbjj;

                        var cocokKategori =
                            !this.filterKategori || item.kategori === this.filterKategori;

                        var cocokStok =
                            this.filterStok === 'semua' ||
                            (this.filterStok === 'menipis' && item.qty > 0 && item.qty < item.safety) ||
                            (this.filterStok === 'kosong' && item.qty === 0);

                        return cocokKata && cocokUpbjj && cocokKategori && cocokStok;
                    }, this);

                    return hasil.sort(function (a, b) {
                        if (this.urutkan === 'qty' || this.urutkan === 'harga') {
                            return a[this.urutkan] - b[this.urutkan];
                        }

                        return a.judul.localeCompare(b.judul);
                    }.bind(this));
                }
            },

            watch: {
                filterUpbjj: function () {
                    this.filterKategori = '';
                }
            },

            methods: {
                formatRupiah: function (angka) {
                    return 'Rp ' + Number(angka).toLocaleString('id-ID');
                },

                resetFilter: function () {
                    this.kataKunci = '';
                    this.filterUpbjj = '';
                    this.filterKategori = '';
                    this.filterStok = 'semua';
                    this.urutkan = 'judul';
                },

                tambahBaru: function () {
                    this.sedangEdit = false;

                    this.formStok = {
                        kode: '',
                        judul: '',
                        kategori: '',
                        upbjj: '',
                        lokasiRak: '',
                        harga: 0,
                        qty: 0,
                        safety: 0,
                        catatanHTML: ''
                    };

                    this.formTampil = true;
                },

                editStok: function (item) {
                    this.sedangEdit = true;
                    this.formStok = Object.assign({}, item);
                    this.formTampil = true;
                },

                simpanStok: function () {
                    if (
                        !this.formStok.kode ||
                        !this.formStok.judul ||
                        !this.formStok.kategori ||
                        !this.formStok.upbjj ||
                        !this.formStok.lokasiRak
                    ) {
                        this.pesanModal = 'Mohon lengkapi semua data.';
                        this.modalPesanTampil = true;
                        return;
                    }

                    if (
                        this.formStok.harga < 0 ||
                        this.formStok.qty < 0 ||
                        this.formStok.safety < 0
                    ) {
                        this.pesanModal = 'Harga dan jumlah stok tidak boleh negatif.';
                        this.modalPesanTampil = true;
                        return;
                    }

                    this.$emit('ubah-stok', {
                        data: Object.assign({}, this.formStok),
                        sedangEdit: this.sedangEdit
                    });

                    this.formTampil = false;
                },

                hapusStok: function (item) {
                    this.kodeHapus = item.kode;
                    this.modalHapusTampil = true;
                },

                lanjutHapus: function () {
                    this.$emit('hapus-stok', this.kodeHapus);

                    this.modalHapusTampil = false;
                    this.kodeHapus = '';
                },

                batalHapus: function () {
                    this.modalHapusTampil = false;
                    this.kodeHapus = '';
                }
            }
        });
    });
