
window.doTrackingReady = fetch('./templates/do-tracking.html')
    .then(function (response) {
        if (!response.ok) {
            throw new Error('Gagal mengambil template do-tracking.html');
        }

        return response.text();
    })
    .then(function (templateHTML) {

        Vue.component('do-tracking', {
            template: templateHTML,

            props: ['items'],

            data: function () {
                return {
                    kataKunci: '',
                    nomorDipilih: '',

                    progressBaru: '',
                    statusProgress: 'Dalam Perjalanan',
                    tanggalProgress: '',
                    jamProgress: '',

                    formProgressTampil: false,
                    modalTampil: false,
                    pesanModal: ''
                };
            },

            computed: {
                // Mengambil data DO yang sedang dipilih.
                doDipilih: function () {
                    return this.items.find(function (item) {
                        return item.nomorDo === this.nomorDipilih;
                    }, this) || null;
                }
            },

            methods: {
                // Mengubah angka menjadi format rupiah.
                formatRupiah: function (angka) {
                    return 'Rp ' + Number(angka).toLocaleString('id-ID');
                },

                // Mencari DO berdasarkan nomor DO atau NIM.
                cariDo: function () {
                    var kata = this.kataKunci.trim().toLowerCase();

                    if (!kata) {
                        this.pesanModal = 'Masukkan Nomor DO atau NIM terlebih dahulu.';
                        this.modalTampil = true;
                        return;
                    }

                    var hasil = this.items.find(function (item) {
                        return String(item.nomorDo).toLowerCase() === kata ||
                            String(item.nim).toLowerCase() === kata;
                    });

                    if (hasil) {
                        this.nomorDipilih = hasil.nomorDo;
                    } else {
                        this.nomorDipilih = '';
                        this.pesanModal = 'Data Delivery Order tidak ditemukan.';
                        this.modalTampil = true;
                    }
                },

                // Mengosongkan pencarian.
                resetCari: function () {
                    this.kataKunci = '';
                    this.nomorDipilih = '';
                    this.progressBaru = '';
                    this.formProgressTampil = false;
                    this.modalTampil = false;
                },

                // Membuka modal tambah riwayat.
                bukaFormProgress: function () {
                    var sekarang = new Date();

                    var tahun = sekarang.getFullYear();
                    var bulan = String(
                        sekarang.getMonth() + 1
                    ).padStart(2, '0');
                    var tanggal = String(
                        sekarang.getDate()
                    ).padStart(2, '0');

                    var jam = String(
                        sekarang.getHours()
                    ).padStart(2, '0');
                    var menit = String(
                        sekarang.getMinutes()
                    ).padStart(2, '0');

                    this.tanggalProgress =
                        tahun + '-' + bulan + '-' + tanggal;

                    this.jamProgress = jam + ':' + menit;

                    this.progressBaru = '';
                    this.statusProgress = 'Dalam Perjalanan';
                    this.formProgressTampil = true;
                },

                // Menutup modal tanpa menyimpan.
                batalProgress: function () {
                    this.formProgressTampil = false;
                    this.progressBaru = '';
                },

                // Menutup modal pemberitahuan.
                tutupModal: function () {
                    this.modalTampil = false;
                },

                // Menyimpan status dan riwayat perjalanan.
                tambahProgress: function () {
                    if (!this.progressBaru.trim()) {
                        this.pesanModal = 'Keterangan perjalanan harus diisi.';
                        this.modalTampil = true;
                        return;
                    }

                    if (!this.tanggalProgress || !this.jamProgress) {
                        this.pesanModal = 'Tanggal dan waktu harus diisi.';
                        this.modalTampil = true;
                        return;
                    }

                    var waktuProgress = this.tanggalProgress + ' ' +
                        this.jamProgress + ':00';

                    this.$emit('tambah-progress', {
                        nomorDo: this.nomorDipilih,
                        status: this.statusProgress,
                        keterangan: this.progressBaru.trim(),
                        waktu: waktuProgress
                    });

                    this.formProgressTampil = false;
                    this.progressBaru = '';

                    this.pesanModal =
                        'Status dan riwayat perjalanan berhasil disimpan.';

                    this.modalTampil = true;
                }
            }
        });
    });
