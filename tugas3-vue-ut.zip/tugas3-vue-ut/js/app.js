
// Menjalankan Vue setelah semua template berhasil dimuat.
Promise.all([
    window.statusBadgeReady,
    window.appModalReady,
    window.stockTableReady,
    window.doTrackingReady,
    window.orderFormReady
]).then(function () {

    // Mengambil data dari file JSON.
    return window.dataService.ambilData();

}).then(function (dataAwal) {

    new Vue({
        el: '#app',

        data: {
            tab: 'stok',
            loading: false,
            errorMessage: '',
            data: dataAwal
        },

        computed: {
            // Membuat nomor DO berikutnya secara otomatis.
            nomorDoBerikutnya: function () {
                var tahun = new Date().getFullYear();
                var nomorTerbesar = 0;

                this.data.tracking.forEach(function (item) {
                    var cocok = item.nomorDo.match(/-(\d+)$/);

                    if (cocok) {
                        nomorTerbesar = Math.max(
                            nomorTerbesar,
                            Number(cocok[1])
                        );
                    }
                });

                return 'DO' + tahun + '-' +
                    String(nomorTerbesar + 1).padStart(4, '0');
            }
        },

        methods: {
            // Menambah atau mengubah data stok bahan ajar.
            ubahStok: function (payload) {
                var posisi = this.data.stok.findIndex(function (item) {
                    return item.kode === payload.data.kode;
                });

                if (payload.sedangEdit) {
                    if (posisi !== -1) {
                        this.$set(
                            this.data.stok,
                            posisi,
                            payload.data
                        );
                    }
                } else {
                    if (posisi !== -1) {
                        alert('Kode bahan ajar sudah digunakan.');
                        return;
                    }

                    this.data.stok.push(payload.data);
                }
            },

            // Menghapus data stok bahan ajar.
            hapusStok: function (kode) {
                this.data.stok = this.data.stok.filter(function (item) {
                    return item.kode !== kode;
                });
            },

            // Menyimpan Delivery Order baru.
            simpanDo: function (dataDo) {
                this.data.tracking.push(dataDo);

                this.$refs.appModal.tampilkan(
                    'Delivery Order berhasil disimpan!'
                );
            },

            // Memperbarui status dan menambahkan riwayat perjalanan.
            tambahProgress: function (payload) {
                var dataDo = this.data.tracking.find(function (item) {
                    return item.nomorDo === payload.nomorDo;
                });

                if (dataDo) {
                    // Memperbarui status Delivery Order.
                    dataDo.status = payload.status;

                    // Menambahkan riwayat perjalanan.
                    dataDo.perjalanan.push({
                        waktu: payload.waktu,
                        keterangan: payload.keterangan
                    });
                }
            }
        }
    });

}).catch(function (error) {

    // Menampilkan pesan jika aplikasi gagal dimuat.
    document.getElementById('app').innerHTML =
        '<h2>Aplikasi gagal dimuat</h2>' +
        '<p>' + error.message + '</p>' +
        '<p>Pastikan proyek dibuka menggunakan Live Server.</p>';

    console.error(error);
});
